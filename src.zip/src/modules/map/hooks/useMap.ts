"use client";

import { useState } from "react";

import {
  DEFAULT_MAP_CENTER,
  DEFAULT_MAP_ZOOM,
} from "@/features/dashboard/constants/dashboardDefaults";

export type MapView = "street" | "satellite";

export function useMap() {
  const [zoom, setZoom] = useState(DEFAULT_MAP_ZOOM);

  const [center, setCenter] =
    useState<[number, number]>(DEFAULT_MAP_CENTER);

  const [bounds, setBounds] =
    useState<[number, number][]>();

  const [markerPosition, setMarkerPosition] =
    useState<[number, number] | null>(null);

  const [mapView, setMapView] =
    useState<MapView>("street");

  function zoomIn() {
    setZoom((current) => Math.min(current * 1.5, 8));
  }

  function zoomOut() {
    setZoom((current) => Math.max(current / 1.5, 0.5));
  }

  function toggleMapView() {
    setMapView((current) =>
      current === "street"
        ? "satellite"
        : "street"
    );
  }

  function moveTo(
    latitude: number,
    longitude: number,
    nextZoom?: number
  ) {
    setCenter([latitude, longitude]);

    setMarkerPosition([latitude, longitude]);

    if (nextZoom !== undefined) {
      setZoom(nextZoom);
    }
  }

  function reset() {
    setZoom(DEFAULT_MAP_ZOOM);
    setCenter(DEFAULT_MAP_CENTER);
    setBounds(undefined);
    setMarkerPosition(null);
  }

  return {
    zoom,
    center,
    bounds,
    markerPosition,
    mapView,

    setBounds,

    zoomIn,
    zoomOut,

    toggleMapView,

    moveTo,

    reset,
  };
}