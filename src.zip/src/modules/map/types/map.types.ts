import type { MapView } from "../store/mapStore";

export interface MapController {
  center: [number, number];
  zoom: number;
  mapView: MapView;

  zoomIn(): void;
  zoomOut(): void;

  toggleMapView(): void;
  resetMap(): void;
}
