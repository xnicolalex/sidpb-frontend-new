"use client";

import type L from "leaflet";
import { create } from "zustand";

export type MapView = "street" | "satellite";

export const DEFAULT_CENTER: [number, number] = [-14.235, -51.925];
export const DEFAULT_ZOOM = 4;

interface MapStore {
  map: L.Map | null;
  mapView: MapView;
  registerMap: (map: L.Map) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  resetMap: () => void;
  toggleMapView: () => void;
}

export const useMapStore = create<MapStore>((set, get) => ({
  map: null,
  mapView: "street",
  registerMap: (map) =>
    set((state) => (state.map === map ? state : { map })),
  zoomIn: () => {
    get().map?.zoomIn();
  },
  zoomOut: () => {
    get().map?.zoomOut();
  },
  resetMap: () => {
    get().map?.flyTo(DEFAULT_CENTER, DEFAULT_ZOOM, {
      animate: true,
      duration: 1.2,
    });
  },
  toggleMapView: () =>
    set((state) => ({
      mapView: state.mapView === "street" ? "satellite" : "street",
    })),
}));
