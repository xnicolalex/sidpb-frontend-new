"use client";

import { useEffect } from "react";
import { useMap } from "react-leaflet";
import { getAdaptiveMinZoom } from "./map-zoom";

export function AdaptiveMinZoom() {
  const map = useMap();

  useEffect(() => {
    function updateMinZoom() {
      map.invalidateSize();

      const nextMinZoom = getAdaptiveMinZoom(map);

      map.setMinZoom(nextMinZoom);

      if (map.getZoom() < nextMinZoom) {
        map.setZoom(nextMinZoom, {
          animate: false,
        });
      }
    }

    updateMinZoom();

    const timeout = window.setTimeout(updateMinZoom, 100);

    map.on("resize", updateMinZoom);
    window.addEventListener("resize", updateMinZoom);

    return () => {
      window.clearTimeout(timeout);
      map.off("resize", updateMinZoom);
      window.removeEventListener("resize", updateMinZoom);
    };
  }, [map]);

  return null;
}
