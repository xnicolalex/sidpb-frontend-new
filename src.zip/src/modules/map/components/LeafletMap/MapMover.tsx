"use client";

import { useEffect } from "react";
import { useMap } from "react-leaflet";
import type L from "leaflet";

interface MapMoverProps {
  center?: [number, number];
  zoom: number;
  bounds?: [number, number][];
}

export function MapMover({ center, zoom, bounds }: MapMoverProps) {
  const map = useMap();

  useEffect(() => {
    if (bounds && bounds.length === 2) {
      map.fitBounds(bounds as L.LatLngBoundsExpression, {
        animate: true,
        duration: 1.5,
      });
      return;
    }

    if (center) {
      map.flyTo(center, map.getZoom(), {
        animate: true,
        duration: 1.5,
      });
    }
  }, [center, bounds, map]);

  useEffect(() => {
    if (map.getZoom() !== zoom) {
      map.setZoom(zoom, {
        animate: true,
      });
    }
  }, [zoom, map]);

  return null;
}
