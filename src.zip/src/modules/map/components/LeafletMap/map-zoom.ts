import type L from "leaflet";

const TILE_SIZE = 256;
const ZOOM_SNAP = 0.25;

export const CLUSTER_MAX_ZOOM = 11;

export function getClusterRadiusByZoom(zoom: number) {
  if (zoom <= 4) return 70;
  if (zoom <= 6) return 55;
  if (zoom <= 8) return 42;
  if (zoom <= 10) return 30;

  return 0;
}

export function getAdaptiveMinZoom(map: L.Map) {
  const mapHeight = map.getSize().y;

  if (!mapHeight) return 0;

  const rawMinZoom = Math.log2(mapHeight / TILE_SIZE);

  return Math.max(0, Math.ceil(rawMinZoom / ZOOM_SNAP) * ZOOM_SNAP);
}
