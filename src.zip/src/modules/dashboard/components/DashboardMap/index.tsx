"use client";

import dynamic from "next/dynamic";

import type {
  OccurrenceFeatureCollection,
} from "@/entities/occurrence/occurrence.types";

import type { MapController } from "@/modules/map/types/map-controller";

const LeafletMap = dynamic(
  () => import("@/modules/map/components/LeafletMap"),
  {
    ssr: false,
  }
);

interface DashboardMapProps {
  map: MapController;
  occurrences: OccurrenceFeatureCollection | null;
}

export function DashboardMap({
  map,
  occurrences,
}: DashboardMapProps) {
  return (
    <div className="absolute inset-0">
      <LeafletMap
        mapView={map.mapView}
        occurrences={occurrences}
        onMapReady={map.registerMap}
        />
    </div>
  );
}