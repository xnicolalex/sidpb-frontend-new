"use client";

import {
  LocateFixed,
  Satellite,
  RotateCcw,
  Map,
} from "lucide-react";

import { ToolButton } from "./ToolButton";
import { ZoomControl } from "./ZoomControl";

import type { MapController } from "@/modules/map/types/map-controller";

interface SidebarToolsProps {
  map: MapController;
}

export function SidebarTools({
  map,
}: SidebarToolsProps) {
  return (
    <section className="shrink-0 border-b">
      <div className="border-b bg-muted/40 px-4 py-2">
        <h2 className="text-sm font-semibold">
          Ferramentas
        </h2>
      </div>

      <div className="space-y-1 p-3">
        <ToolButton
          icon={LocateFixed}
          label="Localizar"
        />

        <ToolButton
          icon={Satellite}
          label="Modo satélite"
          active={map.mapView === "satellite"}
          onClick={map.toggleMapView}
        />

        <ToolButton
          icon={RotateCcw}
          label="Redefinir mapa"
          onClick={map.resetMap}
        />

        <ToolButton
          icon={Map}
          label="Mostrar legenda"
        />

        <ZoomControl
          onZoomIn={map.zoomIn}
          onZoomOut={map.zoomOut}
        />
      </div>
    </section>
  );
}