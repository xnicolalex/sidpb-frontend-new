"use client";

import type { MapController } from "@/modules/map/types/map-controller";

import { SidebarTools } from "./SidebarTools";
import { SidebarFilters } from "./SidebarFilters";

interface DashboardSidebarProps {
  map: MapController;
}

export function DashboardSidebar({
  map,
}: DashboardSidebarProps) {
  return (
    <aside className="flex h-full w-72 flex-col border-r bg-background">

      <SidebarTools map={map} />

      <SidebarFilters />

    </aside>
  );
}