"use client";

import Image from "next/image";
import { parseAsString, useQueryState } from "nuqs";

import { SearchForm } from "@/modules/search/components/SearchForm";

export function DashboardHeader() {
  const [search, setSearch] = useQueryState(
    "search",
    parseAsString.withDefault("")
  );

  function handleSearch(value: string) {
    const nextSearch = value.trim();
    void setSearch(nextSearch.length > 0 ? nextSearch : null);
  }

  return (
    <header className="flex h-16 items-center border-b border-border bg-background px-6">
      <div className="mr-8 flex shrink-0 items-center">
        <Image
          src="/sidpb/logo.svg"
          alt="SIDPB"
          width={120}
          height={42}
          priority
        />
      </div>

      <div className="w-full max-w-3xl">
        <SearchForm
          initialValue={search}
          onSearch={handleSearch}
          placeholder="Pesquise por doenÃ§a, parasito, hospedeiro..."
        />
      </div>
    </header>
  );
}
