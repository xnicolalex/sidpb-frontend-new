import { create } from "zustand";
import { persist } from "zustand/middleware";

type GeographicLevel = "country" | "state" | "city";

interface FiltersState {
  geographicLevel: GeographicLevel;
  selectedRegion: string | null;
  selectedDiseases: string[];
  selectedVectors: string[];
  selectedHosts: string[];
  visibleLayers: string[];
  showLegend: boolean;
  setGeographicLevel: (level: GeographicLevel) => void;
  setSelectedRegion: (region: string | null) => void;
  toggleDisease: (disease: string) => void;
  toggleLayer: (layerId: string) => void;
  setShowLegend: (show: boolean) => void;
  resetFilters: () => void;
}

const STORAGE_KEY = "sidpb-filters-storage";

type FilterValues = Pick<
  FiltersState,
  | "geographicLevel"
  | "selectedRegion"
  | "selectedDiseases"
  | "selectedVectors"
  | "selectedHosts"
  | "visibleLayers"
  | "showLegend"
>;

const initialState: FilterValues = {
  geographicLevel: "country",
  selectedRegion: null,
  selectedDiseases: [],
  selectedVectors: [],
  selectedHosts: [],
  visibleLayers: ["occurrences"],
  showLegend: true,
};

export const useFiltersStore = create<FiltersState>()(
  persist(
    (set) => ({
      ...initialState,
      setGeographicLevel: (level) => set({ geographicLevel: level }),
      setSelectedRegion: (region) => set({ selectedRegion: region }),
      toggleDisease: (disease) =>
        set((state) => ({
          selectedDiseases: state.selectedDiseases.includes(disease)
            ? state.selectedDiseases.filter((item) => item !== disease)
            : [...state.selectedDiseases, disease],
        })),
      toggleLayer: (layerId) =>
        set((state) => ({
          visibleLayers: state.visibleLayers.includes(layerId)
            ? state.visibleLayers.filter((item) => item !== layerId)
            : [...state.visibleLayers, layerId],
        })),
      setShowLegend: (show) => set({ showLegend: show }),
      resetFilters: () =>
        set({
          selectedDiseases: [],
          selectedVectors: [],
          selectedHosts: [],
          geographicLevel: "country",
          selectedRegion: null,
        }),
    }),
    {
      name: STORAGE_KEY,
      partialize: (state) => ({
        geographicLevel: state.geographicLevel,
        selectedRegion: state.selectedRegion,
        selectedDiseases: state.selectedDiseases,
        selectedVectors: state.selectedVectors,
        selectedHosts: state.selectedHosts,
        visibleLayers: state.visibleLayers,
        showLegend: state.showLegend,
      }),
    }
  )
);
